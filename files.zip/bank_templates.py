"""
Bank format templates for 15+ major Indian banks.
Each template defines how to extract transactions from that bank's PDF/Excel format.
"""

import re
from dataclasses import dataclass
from typing import Optional

@dataclass
class BankTemplate:
    name: str
    patterns: list  # regex patterns to match transaction rows
    date_formats: list  # possible date formats
    col_map: dict  # column name mappings
    currency_symbol: str = "Rs"
    encoding: str = "utf-8"

# ─── TRANSACTION REGEX PATTERNS ────────────────────────────────────────────────
# Each pattern tries to extract: date, description, debit, credit, balance

PATTERNS = {
    "hdfc": [
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "sbi": [
        r"(\d{2} \w{3} \d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
        r"(\d{2}/\d{2}/\d{4})\s+(\w+)\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "icici": [
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+(\d+\.\d{2})?\s+(\d+\.\d{2})?\s+(\d+\.\d{2})",
    ],
    "axis": [
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "kotak": [
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "yes": [
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "pnb": [
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "bob": [  # Bank of Baroda
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "canara": [
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "idfc": [
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "indusind": [
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "rbl": [
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "federal": [
        r"(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})?\s+([\d,]+\.\d{2})",
    ],
    "generic": [
        # Most flexible — tries all common formats
        r"(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\s+(.{5,60}?)\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})?\s*(Cr|Dr)?",
        r"(\d{1,2}[-/\s]\w{3}[-/\s]\d{2,4})\s+(.{5,60}?)\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})?",
        r"(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})\s+([\d,]+\.\d{2})",
    ]
}

BANK_IDENTIFIERS = {
    "hdfc": ["hdfc", "hdfc bank", "hdfcbank"],
    "sbi": ["state bank", "sbi", "sbicap"],
    "icici": ["icici", "icici bank"],
    "axis": ["axis bank", "axis"],
    "kotak": ["kotak", "kotak mahindra"],
    "yes": ["yes bank", "yes bank limited"],
    "pnb": ["punjab national", "pnb"],
    "bob": ["bank of baroda", "bob"],
    "canara": ["canara bank", "canara"],
    "idfc": ["idfc", "idfc first"],
    "indusind": ["indusind", "indusind bank"],
    "rbl": ["rbl bank", "ratnakar"],
    "federal": ["federal bank", "the federal"],
    "uco": ["uco bank"],
    "union": ["union bank"],
}

# Transaction category keywords
CATEGORY_MAP = {
    "Salary": ["salary", "sal cr", "payroll", "ctc", "compensation", "wages", "remuneration", "payslip", "monthly pay"],
    "EMI": ["emi", "loan emi", "home loan", "car loan", "personal loan", "housing loan", "vehicle loan", "hl emi", "pl emi"],
    "UPI": ["upi", "upi/", "gpay", "phonepe", "paytm", "bhim", "upi-", "upi cr", "upi dr"],
    "NEFT/RTGS": ["neft", "rtgs", "imps", "neft cr", "rtgs cr", "fund transfer"],
    "ATM": ["atm", "cash withdrawal", "atm wd", "cash wd", "atm-", "atm cash"],
    "Food": ["swiggy", "zomato", "uber eats", "dominos", "pizza", "restaurant", "cafe", "starbucks", "mcd", "kfc", "barbeque", "dineout", "food"],
    "Shopping": ["amazon", "flipkart", "myntra", "ajio", "nykaa", "tatacliq", "meesho", "shopping", "mart", "store", "retail"],
    "Utilities": ["electricity", "bses", "tata power", "water bill", "gas bill", "broadband", "airtel", "jio", "vi ", "bsnl", "mahanagar", "bescom", "msedcl", "electricity board"],
    "Investment": ["sip", "mutual fund", "mf", "zerodha", "groww", "coin", "nse", "bse", "lic", "ppf", "nps", "elss", "ulip", "demat"],
    "Insurance": ["insurance", "lic", "hdfc life", "icici pru", "max life", "bajaj allianz", "star health", "niva bupa", "premium"],
    "Fuel": ["petrol", "fuel", "hp petrol", "ioc", "bpcl", "indian oil", "bharat petroleum"],
    "Travel": ["irctc", "railway", "bus ticket", "makemytrip", "goibibo", "yatra", "cleartrip", "ola", "uber", "rapido", "flight", "air india", "indigo", "spicejet"],
    "Education": ["school fee", "college fee", "tuition", "coaching", "byju", "unacademy", "coursera", "udemy", "fees"],
    "Healthcare": ["pharmacy", "medical", "hospital", "apollo", "fortis", "doctor", "clinic", "labs", "diagnostic", "medicine"],
    "Rent": ["rent", "house rent", "rental", "pg rent", "flat rent", "monthly rent"],
    "Cheque": ["clg", "clearing", "chq", "cheque", "check"],
    "Interest": ["interest", "int cr", "savings interest", "fd interest"],
    "Tax": ["tds", "gst", "income tax", "tax deducted", "advance tax"],
    "Other": []
}

def detect_bank(text: str) -> str:
    """Detect bank name from statement text."""
    text_lower = text.lower()
    for bank_key, identifiers in BANK_IDENTIFIERS.items():
        for identifier in identifiers:
            if identifier in text_lower:
                return bank_key
    return "generic"

def categorize_transaction(description: str) -> str:
    """Categorize a transaction based on description keywords."""
    desc_lower = description.lower()
    for category, keywords in CATEGORY_MAP.items():
        if any(kw in desc_lower for kw in keywords):
            return category
    return "Other"

def is_credit(description: str, amount_str: str = "", cr_dr: str = "") -> bool:
    """Determine if transaction is credit (money in)."""
    cr_keywords = ["salary", "credit", "cr", "received", "refund", "interest", "dividend", "cashback", "reversal"]
    dr_keywords = ["debit", "dr", "withdrawal", "payment", "purchase", "charge", "fee"]
    
    if cr_dr:
        return cr_dr.upper() == "CR"
    
    desc_lower = description.lower()
    if any(k in desc_lower for k in cr_keywords):
        return True
    if any(k in desc_lower for k in dr_keywords):
        return False
    return False

def clean_amount(amount_str: str) -> float:
    """Clean and convert amount string to float."""
    if not amount_str:
        return 0.0
    cleaned = re.sub(r"[^\d.]", "", str(amount_str))
    try:
        return float(cleaned)
    except ValueError:
        return 0.0
