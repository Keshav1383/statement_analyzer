# Bank Statement Analyzer API — Complete Setup Guide

## Quick Start (3 commands)

```bash
pip install fastapi uvicorn pdfplumber pandas openpyxl reportlab httpx python-multipart pillow
uvicorn main:app --reload --port 8000
# API live at: http://localhost:8000
# Swagger docs: http://localhost:8000/docs
```

---

## Files

| File | Purpose |
|------|---------|
| `main.py` | FastAPI server — all API routes |
| `parser.py` | PDF/Excel/CSV parser for 15+ Indian banks |
| `analyzer.py` | Credit scoring, fraud detection, FOIR engine |
| `exporter.py` | PDF credit report + Excel workbook generator |
| `bank_templates.py` | Bank format templates + transaction categorizer |

---

## API Endpoints

### 1. `POST /analyze` — Upload & Analyze (fast, no AI)

```bash
curl -X POST http://localhost:8000/analyze \
  -F "file=@hdfc_statement.pdf"
```

**Response:**
```json
{
  "id": "abc123-...",
  "bank_name": "HDFC Bank",
  "account_holder": "Priya Sharma",
  "account_number": "XXXX 7293",
  "parse_confidence": 0.9,
  "transactions_count": 30,
  "analysis": {
    "summary": {
      "avg_monthly_income": 75000,
      "avg_monthly_expense": 48000,
      "emi_obligations": 18500,
      "foir": 24.7,
      "risk_score": 82,
      "credit_limit": 200000,
      "months_analyzed": 6,
      "total_transactions": 180
    },
    "income_breakdown": [...],
    "spend_breakdown": [...],
    "monthly_flow": [...],
    "fraud_flags": [],
    "decision": {
      "status": "APPROVE",
      "reason": "Strong income stability, low FOIR"
    }
  }
}
```

---

### 2. `POST /analyze/ai` — Upload, Analyze + Claude AI Narrative

```bash
curl -X POST http://localhost:8000/analyze/ai \
  -F "file=@sbi_statement.xlsx"
```

Same response as above + extra field:
```json
{
  "ai_narrative": "Priya Sharma presents a strong credit profile with stable salary income of Rs 68,000/month from Tata Consultancy Services..."
}
```

> Requires Anthropic API key set in env: `export ANTHROPIC_API_KEY=sk-ant-...`

---

### 3. `GET /export/pdf/{id}` — Download PDF Credit Report

```bash
curl -o credit_report.pdf http://localhost:8000/export/pdf/abc123-...
```

Returns: Professional A4 PDF with:
- Account info + credit decision banner
- Key metrics table
- Income/expense breakdown
- Fraud flags
- AI narrative (if available)
- Last 20 transactions

---

### 4. `GET /export/excel/{id}` — Download Excel Report

```bash
curl -o report.xlsx http://localhost:8000/export/excel/abc123-...
```

Returns: Multi-sheet Excel workbook:
- **Sheet 1:** Summary + metrics + fraud flags
- **Sheet 2:** All transactions (categorized)
- **Sheet 3:** Monthly cash flow table

---

### 5. `GET /banks` — List Supported Banks

```bash
curl http://localhost:8000/banks
```

**Returns 16 banks:**
HDFC, SBI, ICICI, Axis, Kotak, Yes Bank, PNB, Bank of Baroda, Canara, IDFC First, IndusInd, RBL, Federal, UCO, Union Bank, Generic Auto-detect

---

### 6. `GET /health` — Health Check

```bash
curl http://localhost:8000/health
# {"status":"healthy","version":"1.0.0","supported_banks":16}
```

---

## Python / JavaScript Integration

### Python
```python
import requests

# Step 1: Analyze
with open("statement.pdf", "rb") as f:
    resp = requests.post("http://localhost:8000/analyze", files={"file": f})

data = resp.json()
analysis_id = data["id"]
risk_score = data["analysis"]["summary"]["risk_score"]
decision = data["analysis"]["decision"]["status"]
print(f"Decision: {decision} | Risk: {risk_score}/100")

# Step 2: Download PDF report
pdf_resp = requests.get(f"http://localhost:8000/export/pdf/{analysis_id}")
with open("credit_report.pdf", "wb") as f:
    f.write(pdf_resp.content)

# Step 3: Download Excel
xl_resp = requests.get(f"http://localhost:8000/export/excel/{analysis_id}")
with open("report.xlsx", "wb") as f:
    f.write(xl_resp.content)
```

### JavaScript / Node.js
```javascript
const FormData = require('form-data');
const fs = require('fs');
const fetch = require('node-fetch');

async function analyzeStatement(filePath) {
  const form = new FormData();
  form.append('file', fs.createReadStream(filePath));

  const resp = await fetch('http://localhost:8000/analyze/ai', {
    method: 'POST',
    body: form,
  });
  const data = await resp.json();

  console.log('Bank:', data.bank_name);
  console.log('Risk Score:', data.analysis.summary.risk_score);
  console.log('Decision:', data.analysis.decision.status);
  console.log('AI Narrative:', data.ai_narrative.substring(0, 200));

  // Download PDF
  const pdfResp = await fetch(`http://localhost:8000/export/pdf/${data.id}`);
  fs.writeFileSync('report.pdf', Buffer.from(await pdfResp.arrayBuffer()));
  return data;
}

analyzeStatement('./hdfc_statement.pdf');
```

---

## Production Deployment

### With Docker
```dockerfile
FROM python:3.12-slim
WORKDIR /app
RUN pip install fastapi uvicorn pdfplumber pandas openpyxl reportlab httpx python-multipart pillow
COPY *.py .
ENV ANTHROPIC_API_KEY=sk-ant-your-key-here
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
docker build -t bsa-api .
docker run -p 8000:8000 -e ANTHROPIC_API_KEY=sk-ant-... bsa-api
```

### Environment Variables
```bash
export ANTHROPIC_API_KEY=sk-ant-...   # Required for /analyze/ai
export BSA_MAX_FILE_SIZE=20971520     # 20MB default
export BSA_PORT=8000
```

---

## Credit Scoring Logic

| Factor | Weight | Notes |
|--------|--------|-------|
| Income stability | +20 | CV < 10% = max score |
| Income level | +15 | >1L/month = max |
| FOIR < 20% | +15 | RBI guideline: <50% |
| Surplus ratio | +10 | >40% surplus = max |
| Transaction history | +5 | >50 transactions |
| Per fraud flag | -8 | Per detected flag |
| FOIR > 50% | -15 | High debt burden |
| Expense > income | -20 | Negative surplus |

**Decision thresholds:**
- **APPROVE:** Score ≥ 70 AND FOIR < 50% AND 0 fraud flags
- **REVIEW:** Score ≥ 50 AND FOIR < 60% AND ≤ 1 fraud flag
- **DECLINE:** Below review thresholds

---

## Supported File Formats

| Format | Banks | Notes |
|--------|-------|-------|
| PDF (text-based) | All 16 banks | Best results |
| PDF (scanned) | Limited | OCR quality varies |
| Excel (.xlsx) | HDFC, SBI, ICICI, Axis, Kotak | Very accurate |
| CSV | Any | Column auto-detection |

---

## Transaction Categories

`Salary` · `EMI` · `UPI` · `NEFT/RTGS` · `ATM` · `Food` · `Shopping` · `Utilities` · `Investment` · `Insurance` · `Fuel` · `Travel` · `Education` · `Healthcare` · `Rent` · `Cheque` · `Interest` · `Tax` · `Other`

---

*Built for Indian banks and NBFCs. RBI guidelines compliant. DPDP Act 2023 ready.*
