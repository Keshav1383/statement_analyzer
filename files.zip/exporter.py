"""
Export Engine
- PDF credit report (professional, bank-ready)
- Excel detailed report (for underwriters)
"""

import io
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether
)
from reportlab.lib import colors
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# Color palette
C_PRIMARY = colors.HexColor("#0F172A")
C_ACCENT  = colors.HexColor("#0EA5E9")
C_GREEN   = colors.HexColor("#16A34A")
C_RED     = colors.HexColor("#DC2626")
C_AMBER   = colors.HexColor("#D97706")
C_LIGHT   = colors.HexColor("#F8FAFC")
C_BORDER  = colors.HexColor("#E2E8F0")
C_MUTED   = colors.HexColor("#64748B")
C_APPROVE = colors.HexColor("#DCFCE7")
C_DECLINE = colors.HexColor("#FEE2E2")
C_REVIEW  = colors.HexColor("#FEF9C3")


def fmt_inr(n: float) -> str:
    """Format number as Indian Rupees."""
    try:
        n = int(round(n))
        if n >= 10000000:
            return f"Rs {n/10000000:.1f} Cr"
        elif n >= 100000:
            return f"Rs {n/100000:.1f} L"
        elif n >= 1000:
            return f"Rs {n/1000:.0f}K"
        return f"Rs {n:,}"
    except Exception:
        return f"Rs {n}"


def generate_pdf_report(
    account_holder: str,
    bank_name: str,
    account_number: str,
    period: str,
    analysis: dict,
    ai_narrative: str = "",
    transactions: list = [],
) -> bytes:
    """Generate a professional PDF credit assessment report."""

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=15*mm, bottomMargin=15*mm,
    )

    styles = getSampleStyleSheet()
    story = []

    def S(name, **kwargs):
        return ParagraphStyle(name, parent=styles["Normal"], **kwargs)

    title_style = S("Title", fontSize=20, textColor=C_PRIMARY, fontName="Helvetica-Bold", spaceAfter=2)
    subtitle_style = S("Sub", fontSize=10, textColor=C_MUTED, spaceAfter=8)
    h2_style = S("H2", fontSize=13, textColor=C_PRIMARY, fontName="Helvetica-Bold", spaceBefore=12, spaceAfter=6)
    h3_style = S("H3", fontSize=11, textColor=C_MUTED, fontName="Helvetica-Bold", spaceBefore=6, spaceAfter=4)
    body_style = S("Body", fontSize=9, textColor=C_PRIMARY, leading=14)
    small_style = S("Small", fontSize=8, textColor=C_MUTED)
    right_style = S("Right", fontSize=9, textColor=C_PRIMARY, alignment=TA_RIGHT)

    s = analysis.get("summary", {})
    decision = analysis.get("decision", {})
    decision_status = decision.get("status", "REVIEW")
    decision_color = {
        "APPROVE": C_GREEN, "DECLINE": C_RED, "REVIEW": C_AMBER
    }.get(decision_status, C_AMBER)
    decision_bg = {
        "APPROVE": C_APPROVE, "DECLINE": C_DECLINE, "REVIEW": C_REVIEW
    }.get(decision_status, C_REVIEW)
    DEC_COLOR_HEX = {"APPROVE": "16A34A", "DECLINE": "DC2626", "REVIEW": "D97706"}.get(decision_status, "D97706")

    # ── HEADER ──
    header_data = [[
        Paragraph(f"<b>Bank Statement Analysis Report</b>", title_style),
        Paragraph(f"<font color='#{DEC_COLOR_HEX}'><b>{decision_status}</b></font>",
                  S("Dec", fontSize=18, fontName="Helvetica-Bold", alignment=TA_RIGHT,
                    textColor=decision_color)),
    ]]
    header_table = Table(header_data, colWidths=[120*mm, 50*mm])
    header_table.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    story.append(header_table)
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceAfter=8))

    # ── ACCOUNT INFO TABLE ──
    story.append(Paragraph("Account Information", h2_style))
    info_data = [
        ["Account Holder", account_holder, "Bank", bank_name],
        ["Account Number", account_number, "Statement Period", period],
        ["Report Generated", datetime.now().strftime("%d %b %Y, %I:%M %p"), "Risk Score", f"{s.get('risk_score',0)}/100"],
    ]
    info_table = Table(info_data, colWidths=[38*mm, 55*mm, 35*mm, 42*mm])
    info_table.setStyle(TableStyle([
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME", (2,0), (2,-1), "Helvetica-Bold"),
        ("TEXTCOLOR", (0,0), (0,-1), C_MUTED),
        ("TEXTCOLOR", (2,0), (2,-1), C_MUTED),
        ("BACKGROUND", (0,0), (-1,-1), C_LIGHT),
        ("GRID", (0,0), (-1,-1), 0.5, C_BORDER),
        ("ROWBACKGROUNDS", (0,0), (-1,-1), [C_LIGHT, colors.white]),
        ("PADDING", (0,0), (-1,-1), 6),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 10))

    # ── DECISION BOX ──
    dec_reason = decision.get("reason", "")
    dec_data = [[
        Paragraph(f"<b>Credit Decision: {decision_status}</b>", 
                  S("DecBox", fontSize=12, fontName="Helvetica-Bold", textColor=decision_color)),
        Paragraph(dec_reason, S("DecReason", fontSize=9, textColor=C_PRIMARY)),
    ]]
    dec_table = Table(dec_data, colWidths=[60*mm, 110*mm])
    dec_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), decision_bg),
        ("GRID", (0,0), (-1,-1), 0.5, decision_color),
        ("PADDING", (0,0), (-1,-1), 8),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
    ]))
    story.append(dec_table)
    story.append(Spacer(1, 12))

    # ── KEY METRICS ──
    story.append(Paragraph("Key Financial Metrics", h2_style))
    metrics = [
        ["Metric", "Value", "Metric", "Value"],
        ["Avg Monthly Income", fmt_inr(s.get("avg_monthly_income",0)),
         "Avg Monthly Expense", fmt_inr(s.get("avg_monthly_expense",0))],
        ["Total Credits (Period)", fmt_inr(s.get("total_credits",0)),
         "Total Debits (Period)", fmt_inr(s.get("total_debits",0))],
        ["EMI Obligations/Month", fmt_inr(s.get("emi_obligations",0)),
         "FOIR", f"{s.get('foir',0)}%"],
        ["Average Balance", fmt_inr(s.get("avg_balance",0)),
         "Recommended Credit Limit", fmt_inr(s.get("credit_limit",0))],
        ["Months Analyzed", str(s.get("months_analyzed",0)),
         "Total Transactions", str(s.get("total_transactions",0))],
    ]
    metrics_table = Table(metrics, colWidths=[50*mm, 45*mm, 50*mm, 25*mm])
    metrics_table.setStyle(TableStyle([
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTNAME", (0,1), (0,-1), "Helvetica-Bold"),
        ("FONTNAME", (2,1), (2,-1), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("BACKGROUND", (0,0), (-1,0), C_PRIMARY),
        ("TEXTCOLOR", (0,1), (0,-1), C_MUTED),
        ("TEXTCOLOR", (2,1), (2,-1), C_MUTED),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [C_LIGHT, colors.white]),
        ("GRID", (0,0), (-1,-1), 0.5, C_BORDER),
        ("PADDING", (0,0), (-1,-1), 6),
        ("ALIGN", (1,1), (1,-1), "RIGHT"),
        ("ALIGN", (3,1), (3,-1), "RIGHT"),
    ]))
    story.append(metrics_table)
    story.append(Spacer(1, 10))

    # ── INCOME BREAKDOWN ──
    income_bd = analysis.get("income_breakdown", [])
    if income_bd:
        story.append(Paragraph("Income Breakdown", h2_style))
        inc_data = [["Income Source", "Amount (Monthly avg)", "% Share"]]
        for item in income_bd:
            inc_data.append([item["label"], fmt_inr(item["amount"]/max(s.get("months_analyzed",1),1)), f"{item['pct']}%"])
        inc_table = Table(inc_data, colWidths=[80*mm, 60*mm, 30*mm])
        inc_table.setStyle(TableStyle([
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 9),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("BACKGROUND", (0,0), (-1,0), C_GREEN),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [C_LIGHT, colors.white]),
            ("GRID", (0,0), (-1,-1), 0.5, C_BORDER),
            ("PADDING", (0,0), (-1,-1), 6),
            ("ALIGN", (2,0), (2,-1), "RIGHT"),
        ]))
        story.append(inc_table)
        story.append(Spacer(1, 10))

    # ── SPEND BREAKDOWN ──
    spend_bd = analysis.get("spend_breakdown", [])
    if spend_bd:
        story.append(Paragraph("Expense Breakdown", h2_style))
        spend_data = [["Expense Category", "Amount (Monthly avg)", "% Share"]]
        for item in spend_bd:
            spend_data.append([item["label"], fmt_inr(item["amount"]/max(s.get("months_analyzed",1),1)), f"{item['pct']}%"])
        spend_table = Table(spend_data, colWidths=[80*mm, 60*mm, 30*mm])
        spend_table.setStyle(TableStyle([
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 9),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("BACKGROUND", (0,0), (-1,0), C_RED),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [C_LIGHT, colors.white]),
            ("GRID", (0,0), (-1,-1), 0.5, C_BORDER),
            ("PADDING", (0,0), (-1,-1), 6),
            ("ALIGN", (2,0), (2,-1), "RIGHT"),
        ]))
        story.append(spend_table)
        story.append(Spacer(1, 10))

    # ── FRAUD FLAGS ──
    flags = analysis.get("fraud_flags", [])
    story.append(Paragraph("Risk & Fraud Assessment", h2_style))
    if flags:
        flag_data = [[Paragraph(f"⚠ {flag}", S("Flag", fontSize=9, textColor=C_RED))] for flag in flags]
        flag_table = Table(flag_data, colWidths=[170*mm])
        flag_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#FFF7F7")),
            ("GRID", (0,0), (-1,-1), 0.5, C_RED),
            ("PADDING", (0,0), (-1,-1), 6),
        ]))
        story.append(flag_table)
    else:
        ok_data = [[Paragraph("✓ No fraud or risk flags detected across all transactions", 
                              S("Ok", fontSize=9, textColor=C_GREEN))]]
        ok_table = Table(ok_data, colWidths=[170*mm])
        ok_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#F0FDF4")),
            ("GRID", (0,0), (-1,-1), 0.5, C_GREEN),
            ("PADDING", (0,0), (-1,-1), 6),
        ]))
        story.append(ok_table)
    story.append(Spacer(1, 10))

    # ── AI NARRATIVE ──
    if ai_narrative:
        story.append(Paragraph("AI Credit Analyst Summary", h2_style))
        for para in ai_narrative.split("\n\n"):
            if para.strip():
                # Strip markdown bold
                clean = para.replace("**", "").strip()
                story.append(Paragraph(clean, body_style))
                story.append(Spacer(1, 4))
        story.append(Spacer(1, 8))

    # ── RECENT TRANSACTIONS ──
    if transactions:
        story.append(Paragraph("Transaction Details (Last 20)", h2_style))
        txn_data = [["Date", "Description", "Type", "Amount", "Category"]]
        for t in transactions[:20]:
            txn_data.append([
                t.get("date","")[:10],
                t.get("description","")[:40],
                t.get("type","").upper(),
                fmt_inr(t.get("amount",0)),
                t.get("category",""),
            ])
        txn_table = Table(txn_data, colWidths=[22*mm, 70*mm, 14*mm, 28*mm, 26*mm])
        txn_table.setStyle(TableStyle([
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 8),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("BACKGROUND", (0,0), (-1,0), C_PRIMARY),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [C_LIGHT, colors.white]),
            ("GRID", (0,0), (-1,-1), 0.3, C_BORDER),
            ("PADDING", (0,0), (-1,-1), 5),
            ("ALIGN", (3,0), (3,-1), "RIGHT"),
        ]))
        story.append(txn_table)
        story.append(Spacer(1, 10))

    # ── FOOTER ──
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER, spaceBefore=6))
    story.append(Paragraph(
        "DISCLAIMER: This report is AI-generated for decision support purposes only. "
        "Final credit decisions must be made by a qualified credit officer in compliance with RBI guidelines, "
        "DPDP Act 2023, and your institution's internal credit policy. "
        f"Generated: {datetime.now().strftime('%d %b %Y %I:%M %p')}",
        S("Footer", fontSize=7, textColor=C_MUTED, alignment=TA_CENTER)
    ))

    doc.build(story)
    return buf.getvalue()


def generate_excel_report(
    account_holder: str,
    bank_name: str,
    account_number: str,
    period: str,
    analysis: dict,
    transactions: list = [],
) -> bytes:
    """Generate detailed Excel report for underwriters."""
    
    wb = openpyxl.Workbook()

    # Styles
    def hdr_fill(hex_color):
        return PatternFill("solid", fgColor=hex_color)
    
    bold = Font(bold=True)
    white_bold = Font(bold=True, color="FFFFFF")
    center = Alignment(horizontal="center", vertical="center")
    right_align = Alignment(horizontal="right")
    thin = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0"),
    )

    # ── SHEET 1: SUMMARY ──
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 30
    ws.column_dimensions["D"].width = 22

    # Title
    ws.merge_cells("A1:D1")
    ws["A1"] = "Bank Statement Analysis Report"
    ws["A1"].font = Font(bold=True, size=16, color="0F172A")
    ws["A1"].fill = hdr_fill("F8FAFC")
    ws["A1"].alignment = center
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:D2")
    ws["A2"] = f"{account_holder} | {bank_name} | {account_number} | {period}"
    ws["A2"].font = Font(size=10, color="64748B")
    ws["A2"].alignment = center

    # Decision
    s = analysis.get("summary", {})
    decision = analysis.get("decision", {})
    decision_status = decision.get("status", "REVIEW")
    dec_colors = {"APPROVE": "16A34A", "DECLINE": "DC2626", "REVIEW": "D97706"}
    DEC_COLOR_HEX = dec_colors.get(decision_status, "D97706")
    
    ws.merge_cells("A3:D3")
    ws["A3"] = f"CREDIT DECISION: {decision_status} — {decision.get('reason','')}"
    ws["A3"].font = Font(bold=True, color="FFFFFF", size=11)
    ws["A3"].fill = hdr_fill(dec_colors.get(decision_status, "D97706"))
    ws["A3"].alignment = center
    ws.row_dimensions[3].height = 22

    row = 5
    # Key metrics headers
    for col, val in enumerate(["Metric", "Value", "Metric", "Value"], 1):
        c = ws.cell(row, col, val)
        c.font = white_bold
        c.fill = hdr_fill("0F172A")
        c.alignment = center
        c.border = thin

    metrics_rows = [
        ("Avg Monthly Income", fmt_inr(s.get("avg_monthly_income",0)), "Avg Monthly Expense", fmt_inr(s.get("avg_monthly_expense",0))),
        ("Total Credits", fmt_inr(s.get("total_credits",0)), "Total Debits", fmt_inr(s.get("total_debits",0))),
        ("EMI Obligations/Month", fmt_inr(s.get("emi_obligations",0)), "FOIR (%)", f"{s.get('foir',0)}%"),
        ("Average Balance", fmt_inr(s.get("avg_balance",0)), "Recommended Credit Limit", fmt_inr(s.get("credit_limit",0))),
        ("Risk Score", f"{s.get('risk_score',0)}/100", "Months Analyzed", str(s.get("months_analyzed",0))),
        ("Total Transactions", str(s.get("total_transactions",0)), "Report Generated", datetime.now().strftime("%d %b %Y")),
    ]
    for i, (a, b, c_val, d) in enumerate(metrics_rows):
        row += 1
        fill = hdr_fill("F8FAFC") if i % 2 == 0 else PatternFill()
        for col, val in enumerate([a, b, c_val, d], 1):
            cell = ws.cell(row, col, val)
            cell.border = thin
            if col in (1, 3):
                cell.font = Font(bold=True, color="64748B", size=9)
            else:
                cell.font = Font(size=9)
                cell.alignment = right_align
            if fill.fill_type:
                cell.fill = fill

    # Fraud flags
    row += 2
    ws.cell(row, 1, "Risk & Fraud Flags").font = Font(bold=True, size=11)
    row += 1
    flags = analysis.get("fraud_flags", [])
    if flags:
        for flag in flags:
            ws.merge_cells(f"A{row}:D{row}")
            cell = ws.cell(row, 1, f"⚠ {flag}")
            cell.font = Font(color="DC2626", size=9)
            cell.fill = hdr_fill("FEF2F2")
            cell.border = thin
            row += 1
    else:
        ws.merge_cells(f"A{row}:D{row}")
        cell = ws.cell(row, 1, "✓ No fraud or risk flags detected")
        cell.font = Font(color="16A34A", size=9)
        cell.fill = hdr_fill("F0FDF4")
        cell.border = thin

    # ── SHEET 2: TRANSACTIONS ──
    ws2 = wb.create_sheet("Transactions")
    ws2.sheet_view.showGridLines = False
    headers = ["Date", "Description", "Type", "Amount (Rs)", "Category", "Balance (Rs)"]
    col_widths = [14, 45, 10, 16, 18, 16]
    for i, (h, w) in enumerate(zip(headers, col_widths), 1):
        ws2.column_dimensions[get_column_letter(i)].width = w
        cell = ws2.cell(1, i, h)
        cell.font = white_bold
        cell.fill = hdr_fill("0F172A")
        cell.alignment = center
        cell.border = thin

    for r, t in enumerate(transactions, 2):
        row_data = [
            t.get("date", ""), t.get("description", ""),
            t.get("type", "").upper(), t.get("amount", 0),
            t.get("category", ""), t.get("balance", 0),
        ]
        is_cr = t.get("type") == "credit"
        fill_color = "F0FDF4" if is_cr else "FFF7F7"
        for c, val in enumerate(row_data, 1):
            cell = ws2.cell(r, c, val)
            cell.border = thin
            cell.font = Font(size=9)
            if c in (4, 6):
                cell.alignment = right_align
                cell.number_format = '#,##0.00'
            if c == 3:
                cell.font = Font(
                    bold=True, size=9,
                    color="16A34A" if is_cr else "DC2626"
                )
            if r % 2 == 0:
                cell.fill = hdr_fill(fill_color if c == 3 else "F8FAFC")

    # ── SHEET 3: MONTHLY FLOW ──
    ws3 = wb.create_sheet("Monthly Flow")
    ws3.sheet_view.showGridLines = False
    ws3.column_dimensions["A"].width = 12
    ws3.column_dimensions["B"].width = 18
    ws3.column_dimensions["C"].width = 18
    ws3.column_dimensions["D"].width = 18
    
    for i, h in enumerate(["Month", "Income (Rs)", "Expense (Rs)", "Surplus (Rs)"], 1):
        cell = ws3.cell(1, i, h)
        cell.font = white_bold
        cell.fill = hdr_fill("0EA5E9")
        cell.alignment = center
        cell.border = thin

    for r, m in enumerate(analysis.get("monthly_flow", []), 2):
        surplus = m.get("income", 0) - m.get("expense", 0)
        row_data = [m.get("month",""), m.get("income",0), m.get("expense",0), surplus]
        for c, val in enumerate(row_data, 1):
            cell = ws3.cell(r, c, val)
            cell.border = thin
            cell.font = Font(size=9)
            if c > 1:
                cell.alignment = right_align
                cell.number_format = '#,##0'
            if c == 4:
                cell.font = Font(size=9, color="16A34A" if surplus >= 0 else "DC2626")
            if r % 2 == 0:
                cell.fill = hdr_fill("F8FAFC")

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
