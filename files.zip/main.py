"""
Bank Statement Analyzer API
FastAPI backend — production ready

Endpoints:
  POST /analyze          → Upload PDF/Excel, get full analysis JSON
  POST /analyze/ai       → Upload + Claude AI narrative
  GET  /export/pdf/{id}  → Download PDF report
  GET  /export/excel/{id}→ Download Excel report
  GET  /health           → Health check
  GET  /banks            → List supported banks
  GET  /docs             → Swagger UI (auto)
"""

import os, sys, uuid, json, asyncio
from datetime import datetime
from typing import Optional
from pathlib import Path
import httpx

from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse, StreamingResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

sys.path.insert(0, str(Path(__file__).parent))
from parser import parse_statement
from analyzer import analyze
from exporter import generate_pdf_report, generate_excel_report

# ─── APP SETUP ────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Bank Statement Analyzer API",
    description="India's most advanced bank statement intelligence API. "
                "Parse, analyze, score, and export credit reports from bank statements.",
    version="1.0.0",
    contact={"name": "BSA API", "email": "api@bsa.in"},
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory store (use Redis/DB in production)
STORE = {}

SUPPORTED_BANKS = [
    {"key": "hdfc",     "name": "HDFC Bank",              "formats": ["PDF", "Excel"]},
    {"key": "sbi",      "name": "State Bank of India",    "formats": ["PDF", "Excel", "CSV"]},
    {"key": "icici",    "name": "ICICI Bank",              "formats": ["PDF", "Excel"]},
    {"key": "axis",     "name": "Axis Bank",               "formats": ["PDF", "Excel"]},
    {"key": "kotak",    "name": "Kotak Mahindra Bank",     "formats": ["PDF", "Excel"]},
    {"key": "yes",      "name": "Yes Bank",                "formats": ["PDF"]},
    {"key": "pnb",      "name": "Punjab National Bank",   "formats": ["PDF", "Excel"]},
    {"key": "bob",      "name": "Bank of Baroda",          "formats": ["PDF"]},
    {"key": "canara",   "name": "Canara Bank",             "formats": ["PDF"]},
    {"key": "idfc",     "name": "IDFC First Bank",         "formats": ["PDF", "Excel"]},
    {"key": "indusind", "name": "IndusInd Bank",           "formats": ["PDF", "Excel"]},
    {"key": "rbl",      "name": "RBL Bank",                "formats": ["PDF"]},
    {"key": "federal",  "name": "Federal Bank",            "formats": ["PDF"]},
    {"key": "uco",      "name": "UCO Bank",                "formats": ["PDF"]},
    {"key": "union",    "name": "Union Bank of India",     "formats": ["PDF"]},
    {"key": "generic",  "name": "Other / Auto-detect",    "formats": ["PDF", "Excel", "CSV"]},
]


# ─── RESPONSE MODELS ──────────────────────────────────────────────────────────

class AnalysisResponse(BaseModel):
    id: str
    status: str
    bank_name: str
    bank_key: str
    account_holder: str
    account_number: str
    period_from: str
    period_to: str
    parse_confidence: float
    analysis: dict
    transactions_count: int
    ai_narrative: Optional[str] = None
    errors: list
    timestamp: str


# ─── HELPERS ──────────────────────────────────────────────────────────────────

async def get_ai_narrative(stmt, analysis_result: dict) -> str:
    """Call Claude API for credit narrative."""
    s = analysis_result.get("summary", {})
    decision = analysis_result.get("decision", {})

    prompt = f"""You are a senior credit analyst at an Indian bank. Write a professional credit assessment narrative.

ACCOUNT: {stmt.account_holder} | {stmt.bank_name}
PERIOD: {stmt.period_from} to {stmt.period_to}

KEY METRICS:
- Avg Monthly Income: Rs {s.get('avg_monthly_income', 0):,}
- Avg Monthly Expense: Rs {s.get('avg_monthly_expense', 0):,}
- EMI Obligations: Rs {s.get('emi_obligations', 0):,}/month
- FOIR: {s.get('foir', 0)}%
- Risk Score: {s.get('risk_score', 0)}/100
- Recommended Credit Limit: Rs {s.get('credit_limit', 0):,}

INCOME SOURCES: {json.dumps(analysis_result.get('income_breakdown', [])[:3])}
FRAUD FLAGS: {json.dumps(analysis_result.get('fraud_flags', []))}
DECISION: {decision.get('status', 'REVIEW')}

Write a 4-5 paragraph professional credit assessment. Include:
1. Income profile summary
2. Expense pattern analysis  
3. EMI/debt burden assessment
4. Risk observations
5. Final recommendation with reasoning

Use **bold** for key numbers and important points. Be specific with rupee amounts."""

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 1000,
                    "messages": [{"role": "user", "content": prompt}],
                },
                headers={"Content-Type": "application/json"},
            )
            data = resp.json()
            blocks = data.get("content", [])
            return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
    except Exception as e:
        return f"AI narrative unavailable: {str(e)}"


# ─── ROUTES ───────────────────────────────────────────────────────────────────

@app.get("/health", tags=["System"])
async def health():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "supported_banks": len(SUPPORTED_BANKS),
    }


@app.get("/banks", tags=["System"])
async def list_banks():
    """List all supported Indian banks and formats."""
    return {"banks": SUPPORTED_BANKS, "total": len(SUPPORTED_BANKS)}


@app.post("/analyze", response_model=AnalysisResponse, tags=["Analysis"])
async def analyze_statement(
    file: UploadFile = File(..., description="Bank statement PDF, Excel (.xlsx/.xls) or CSV"),
):
    """
    **Upload and analyze a bank statement.**
    
    - Supports 15+ Indian bank formats
    - Auto-detects bank type
    - Returns full credit analysis including income, expenses, FOIR, risk score
    - Does NOT call AI (faster, use /analyze/ai for AI narrative)
    
    **Supported formats:** PDF, XLSX, XLS, CSV
    """
    content_type = file.content_type or ""
    filename = file.filename or "statement.pdf"
    
    allowed_types = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
        "text/csv",
        "application/octet-stream",
    ]
    
    ext = filename.lower().split(".")[-1]
    if ext not in ("pdf", "xlsx", "xls", "csv"):
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Use PDF, XLSX, XLS, or CSV."
        )

    file_bytes = await file.read()
    if len(file_bytes) > 20 * 1024 * 1024:  # 20MB limit
        raise HTTPException(status_code=413, detail="File too large. Max 20MB.")

    # Parse
    stmt = parse_statement(file_bytes, filename)

    # Analyze
    analysis_result = analyze(stmt.transactions, stmt.account_holder)

    # Store for export
    analysis_id = str(uuid.uuid4())
    STORE[analysis_id] = {
        "stmt": stmt,
        "analysis": analysis_result,
        "ai_narrative": "",
        "created_at": datetime.now().isoformat(),
    }

    return AnalysisResponse(
        id=analysis_id,
        status="success",
        bank_name=stmt.bank_name,
        bank_key=stmt.bank_key,
        account_holder=stmt.account_holder,
        account_number=stmt.account_number,
        period_from=stmt.period_from,
        period_to=stmt.period_to,
        parse_confidence=stmt.parse_confidence,
        analysis=analysis_result,
        transactions_count=len(stmt.transactions),
        errors=stmt.errors,
        timestamp=datetime.now().isoformat(),
    )


@app.post("/analyze/ai", response_model=AnalysisResponse, tags=["Analysis"])
async def analyze_with_ai(
    file: UploadFile = File(..., description="Bank statement file"),
):
    """
    **Upload, analyze, AND generate AI credit narrative.**
    
    Same as /analyze but also calls Claude AI to write a professional
    credit assessment narrative (adds ~3-5 seconds).
    
    The `ai_narrative` field contains a detailed analyst-style report.
    """
    # Reuse base analysis
    content_type = file.content_type or ""
    filename = file.filename or "statement.pdf"
    ext = filename.lower().split(".")[-1]
    
    if ext not in ("pdf", "xlsx", "xls", "csv"):
        raise HTTPException(status_code=400, detail=f"Unsupported file type '{ext}'.")

    file_bytes = await file.read()
    if len(file_bytes) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File too large. Max 20MB.")

    stmt = parse_statement(file_bytes, filename)
    analysis_result = analyze(stmt.transactions, stmt.account_holder)

    # AI narrative
    ai_text = await get_ai_narrative(stmt, analysis_result)

    analysis_id = str(uuid.uuid4())
    STORE[analysis_id] = {
        "stmt": stmt,
        "analysis": analysis_result,
        "ai_narrative": ai_text,
        "created_at": datetime.now().isoformat(),
    }

    return AnalysisResponse(
        id=analysis_id,
        status="success",
        bank_name=stmt.bank_name,
        bank_key=stmt.bank_key,
        account_holder=stmt.account_holder,
        account_number=stmt.account_number,
        period_from=stmt.period_from,
        period_to=stmt.period_to,
        parse_confidence=stmt.parse_confidence,
        analysis=analysis_result,
        transactions_count=len(stmt.transactions),
        ai_narrative=ai_text,
        errors=stmt.errors,
        timestamp=datetime.now().isoformat(),
    )


@app.get("/export/pdf/{analysis_id}", tags=["Export"])
async def export_pdf(analysis_id: str):
    """
    **Download PDF credit report for a previously analyzed statement.**
    
    Call `/analyze` or `/analyze/ai` first to get an `id`, then use it here.
    Returns a professional A4 PDF ready for bank/NBFC use.
    """
    data = STORE.get(analysis_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found. Run /analyze first.")

    stmt = data["stmt"]
    s = analysis_result = data["analysis"]
    ai_text = data.get("ai_narrative", "")

    period = f"{stmt.period_from} to {stmt.period_to}" if stmt.period_from else "N/A"

    pdf_bytes = generate_pdf_report(
        account_holder=stmt.account_holder,
        bank_name=stmt.bank_name,
        account_number=stmt.account_number,
        period=period,
        analysis=analysis_result,
        ai_narrative=ai_text,
        transactions=stmt.transactions[:30],
    )

    filename = f"credit_report_{stmt.account_holder.replace(' ','_')}_{datetime.now().strftime('%Y%m%d')}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/export/excel/{analysis_id}", tags=["Export"])
async def export_excel(analysis_id: str):
    """
    **Download Excel report for a previously analyzed statement.**
    
    Returns a multi-sheet Excel workbook:
    - Sheet 1: Summary + Key Metrics
    - Sheet 2: All Transactions (categorized)
    - Sheet 3: Monthly Cash Flow
    """
    data = STORE.get(analysis_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found. Run /analyze first.")

    stmt = data["stmt"]
    analysis_result = data["analysis"]
    period = f"{stmt.period_from} to {stmt.period_to}" if stmt.period_from else "N/A"

    excel_bytes = generate_excel_report(
        account_holder=stmt.account_holder,
        bank_name=stmt.bank_name,
        account_number=stmt.account_number,
        period=period,
        analysis=analysis_result,
        transactions=stmt.transactions,
    )

    filename = f"bsa_{stmt.account_holder.replace(' ','_')}_{datetime.now().strftime('%Y%m%d')}.xlsx"
    return Response(
        content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/", tags=["System"])
async def root():
    return {
        "name": "Bank Statement Analyzer API",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": {
            "POST /analyze": "Upload statement → get analysis JSON",
            "POST /analyze/ai": "Upload statement → get analysis + AI narrative",
            "GET /export/pdf/{id}": "Download PDF credit report",
            "GET /export/excel/{id}": "Download Excel report",
            "GET /banks": "List supported banks",
            "GET /health": "Health check",
        }
    }
