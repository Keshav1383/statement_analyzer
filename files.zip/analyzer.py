"""
Analysis Engine
- Income analysis (salary, business, freelance)
- Expense categorization
- EMI/FOIR calculation
- Fraud detection (circular txns, cash stuffing, lien alerts)
- Credit scoring (0-100)
- Monthly cash flow analysis
"""

from collections import defaultdict
from statistics import mean, stdev
import math


def analyze(transactions: list, account_holder: str = "") -> dict:
    """Run full analysis on parsed transactions. Returns complete analysis dict."""
    
    if not transactions:
        return _empty_analysis()

    credits = [t for t in transactions if t["type"] == "credit"]
    debits = [t for t in transactions if t["type"] == "debit"]

    total_credits = sum(t["amount"] for t in credits)
    total_debits = sum(t["amount"] for t in debits)

    # Monthly grouping
    monthly = _group_monthly(transactions)
    months_count = max(len(monthly), 1)

    avg_monthly_income = total_credits / months_count
    avg_monthly_expense = total_debits / months_count

    # Income sources
    income_sources = _analyze_income(credits)

    # Expense categories
    expense_cats = _analyze_expenses(debits)

    # EMI detection
    emi_amount = _detect_emi(debits)

    # FOIR
    foir = round((emi_amount / avg_monthly_income * 100), 1) if avg_monthly_income > 0 else 0

    # Fraud flags
    fraud_flags = _detect_fraud(transactions, monthly)

    # Risk score
    risk_score = _calculate_risk_score(
        avg_monthly_income=avg_monthly_income,
        avg_monthly_expense=avg_monthly_expense,
        foir=foir,
        fraud_flags=fraud_flags,
        monthly=monthly,
        months_count=months_count,
        emi_amount=emi_amount,
        transactions=transactions,
    )

    # Recommended credit limit (typically 3-5x monthly income)
    surplus = avg_monthly_income - avg_monthly_expense
    credit_multiplier = 4 if risk_score >= 70 else 3 if risk_score >= 50 else 2
    credit_limit = round(surplus * credit_multiplier / 1000) * 1000

    # Average balance from transaction balances
    balances = [t["balance"] for t in transactions if t.get("balance", 0) > 0]
    avg_balance = round(mean(balances)) if balances else 0

    # Monthly flow for chart
    monthly_flow = []
    for month_key in sorted(monthly.keys())[-6:]:  # last 6 months
        m = monthly[month_key]
        monthly_flow.append({
            "month": _short_month(month_key),
            "income": round(m["income"]),
            "expense": round(m["expense"]),
            "balance": round(m["income"] - m["expense"]),
        })

    return {
        "summary": {
            "avg_monthly_income": round(avg_monthly_income),
            "avg_monthly_expense": round(avg_monthly_expense),
            "avg_balance": avg_balance,
            "total_credits": round(total_credits),
            "total_debits": round(total_debits),
            "emi_obligations": round(emi_amount),
            "foir": foir,
            "risk_score": risk_score,
            "credit_limit": max(credit_limit, 0),
            "months_analyzed": months_count,
            "total_transactions": len(transactions),
        },
        "income_breakdown": income_sources,
        "spend_breakdown": expense_cats,
        "monthly_flow": monthly_flow,
        "fraud_flags": fraud_flags,
        "decision": _credit_decision(risk_score, foir, fraud_flags),
    }


def _group_monthly(transactions: list) -> dict:
    """Group transactions by month."""
    monthly = defaultdict(lambda: {"income": 0, "expense": 0, "txns": []})

    for t in transactions:
        date_str = t.get("date", "")
        month_key = _extract_month_key(date_str)
        if not month_key:
            continue
        if t["type"] == "credit":
            monthly[month_key]["income"] += t["amount"]
        else:
            monthly[month_key]["expense"] += t["amount"]
        monthly[month_key]["txns"].append(t)

    return dict(monthly)


def _extract_month_key(date_str: str) -> str:
    """Extract YYYY-MM from various date formats."""
    import re
    patterns = [
        r"(\d{4})-(\d{2})-\d{2}",
        r"(\d{2})/(\d{2})/(\d{4})",
        r"(\d{2})-(\d{2})-(\d{4})",
        r"(\d{2}) (\w{3}) (\d{4})",
    ]
    month_names = {"jan":"01","feb":"02","mar":"03","apr":"04","may":"05","jun":"06",
                   "jul":"07","aug":"08","sep":"09","oct":"10","nov":"11","dec":"12"}

    m = re.search(r"(\d{4})-(\d{2})", date_str)
    if m:
        return f"{m.group(1)}-{m.group(2)}"

    m = re.search(r"(\d{2})[/\-](\d{2})[/\-](\d{4})", date_str)
    if m:
        return f"{m.group(3)}-{m.group(2).zfill(2)}"

    m = re.search(r"(\d{2})\s+(\w{3})\s+(\d{4})", date_str)
    if m:
        mon = month_names.get(m.group(2).lower(), "01")
        return f"{m.group(3)}-{mon}"

    return ""


def _short_month(key: str) -> str:
    months = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    try:
        _, m = key.split("-")
        return months[int(m)]
    except Exception:
        return key


def _analyze_income(credits: list) -> list:
    """Break down income by source/category."""
    sources = defaultdict(float)
    for t in credits:
        sources[t.get("category", "Other")] += t["amount"]

    total = sum(sources.values()) or 1
    result = []
    for cat, amt in sorted(sources.items(), key=lambda x: -x[1]):
        result.append({
            "label": cat,
            "amount": round(amt),
            "pct": round(amt / total * 100),
        })
    return result[:6]


def _analyze_expenses(debits: list) -> list:
    """Break down expenses by category."""
    cats = defaultdict(float)
    for t in debits:
        cats[t.get("category", "Other")] += t["amount"]

    total = sum(cats.values()) or 1
    colors = {
        "EMI": "#EF4444", "UPI": "#3B82F6", "Shopping": "#10B981",
        "Food": "#F59E0B", "Utilities": "#8B5CF6", "Fuel": "#06B6D4",
        "Travel": "#EC4899", "ATM": "#F97316", "Insurance": "#6366F1",
        "Investment": "#14B8A6", "Other": "#6B7280",
    }
    result = []
    for cat, amt in sorted(cats.items(), key=lambda x: -x[1]):
        result.append({
            "label": cat,
            "amount": round(amt),
            "pct": round(amt / total * 100),
            "color": colors.get(cat, "#6B7280"),
        })
    return result[:8]


def _detect_emi(debits: list) -> float:
    """Detect regular recurring debit amounts (likely EMIs)."""
    # Group by approximate amount (within 5%) and check regularity
    amount_groups = defaultdict(list)
    for t in debits:
        if t["amount"] > 500:  # ignore small amounts
            # Round to nearest 500 for grouping
            key = round(t["amount"] / 500) * 500
            amount_groups[key].append(t)

    emi_total = 0.0
    emi_keywords = ["emi", "loan", "lending", "finance", "housing", "vehicle"]
    
    for amt_key, txns in amount_groups.items():
        # If same amount appears 2+ times across different months
        months = set()
        for t in txns:
            mk = _extract_month_key(t.get("date", ""))
            if mk:
                months.add(mk)
        
        desc = " ".join(t["description"].lower() for t in txns)
        is_emi = any(k in desc for k in emi_keywords) or len(months) >= 2
        
        if is_emi:
            emi_total += amt_key

    return emi_total


def _detect_fraud(transactions: list, monthly: dict) -> list:
    """Detect fraud and risk patterns."""
    flags = []

    # 1. Large cash withdrawals (ATM > 50% of monthly income)
    atm_txns = [t for t in transactions if t.get("category") == "ATM"]
    if atm_txns:
        total_atm = sum(t["amount"] for t in atm_txns)
        months = len(monthly) or 1
        if total_atm / months > 30000:
            flags.append(f"High cash withdrawals: avg Rs {round(total_atm/months):,}/month — potential cash stuffing risk")

    # 2. Circular transactions (credit followed by same-amount debit within 3 days)
    credits = sorted([t for t in transactions if t["type"] == "credit"], key=lambda x: x.get("date", ""))
    debits_amts = {round(t["amount"]): t for t in transactions if t["type"] == "debit"}
    circular_count = 0
    for c in credits:
        if round(c["amount"]) in debits_amts:
            circular_count += 1
    if circular_count > 3:
        flags.append(f"Possible circular transactions detected: {circular_count} matching credit/debit pairs")

    # 3. Sudden income spike > 3x average
    if len(monthly) >= 3:
        monthly_incomes = [v["income"] for v in monthly.values() if v["income"] > 0]
        if len(monthly_incomes) >= 2:
            avg_inc = mean(monthly_incomes)
            max_inc = max(monthly_incomes)
            if max_inc > avg_inc * 3:
                flags.append(f"Income spike detected: one month shows Rs {round(max_inc):,} vs avg Rs {round(avg_inc):,} — verify source")

    # 4. Cheque bounces
    bounce_keywords = ["bounce", "dishonour", "returned", "insufficient", "chargeback"]
    bounce_txns = [t for t in transactions if any(k in t["description"].lower() for k in bounce_keywords)]
    if bounce_txns:
        flags.append(f"{len(bounce_txns)} cheque bounce(s) / return(s) detected — credit risk indicator")

    # 5. Multiple loan EMI payments (potential debt trap)
    emi_txns = [t for t in transactions if t.get("category") == "EMI"]
    unique_emi_desc = set(t["description"][:20].lower() for t in emi_txns)
    if len(unique_emi_desc) > 3:
        flags.append(f"Multiple loan obligations detected ({len(unique_emi_desc)} different EMIs) — verify total debt burden")

    return flags


def _calculate_risk_score(avg_monthly_income, avg_monthly_expense, foir,
                          fraud_flags, monthly, months_count, emi_amount, transactions) -> int:
    """Calculate risk score 0-100 (higher = safer)."""
    score = 50  # base

    # Income stability (+20)
    if months_count >= 6:
        monthly_incomes = [v["income"] for v in monthly.values() if v["income"] > 0]
        if len(monthly_incomes) >= 2:
            cv = stdev(monthly_incomes) / mean(monthly_incomes) if mean(monthly_incomes) > 0 else 1
            if cv < 0.1:
                score += 20  # very stable
            elif cv < 0.2:
                score += 15
            elif cv < 0.3:
                score += 8
            else:
                score += 0
    elif months_count >= 3:
        score += 8

    # Income level (+15)
    if avg_monthly_income > 100000:
        score += 15
    elif avg_monthly_income > 50000:
        score += 10
    elif avg_monthly_income > 25000:
        score += 5
    elif avg_monthly_income < 15000:
        score -= 10

    # FOIR impact (+/- 15)
    if foir < 20:
        score += 15
    elif foir < 30:
        score += 10
    elif foir < 40:
        score += 5
    elif foir < 50:
        score -= 5
    elif foir < 60:
        score -= 15
    else:
        score -= 25

    # Surplus ratio (+10)
    if avg_monthly_income > 0:
        surplus_ratio = (avg_monthly_income - avg_monthly_expense) / avg_monthly_income
        if surplus_ratio > 0.4:
            score += 10
        elif surplus_ratio > 0.25:
            score += 6
        elif surplus_ratio > 0.1:
            score += 2
        elif surplus_ratio < 0:
            score -= 20

    # Fraud flags (- per flag)
    score -= len(fraud_flags) * 8

    # Transaction volume (+5 if sufficient history)
    if len(transactions) > 50:
        score += 5
    elif len(transactions) < 10:
        score -= 5

    return max(0, min(100, score))


def _credit_decision(risk_score: int, foir: float, fraud_flags: list) -> dict:
    """Generate credit decision."""
    if risk_score >= 70 and foir < 50 and len(fraud_flags) == 0:
        return {"status": "APPROVE", "color": "success", "reason": "Strong income stability, low FOIR, no risk flags"}
    elif risk_score >= 50 and foir < 60 and len(fraud_flags) <= 1:
        return {"status": "REVIEW", "color": "warning", "reason": "Moderate profile — manual underwriter review recommended"}
    else:
        return {"status": "DECLINE", "color": "danger", "reason": "High risk indicators — does not meet credit criteria"}


def _empty_analysis() -> dict:
    return {
        "summary": {
            "avg_monthly_income": 0, "avg_monthly_expense": 0, "avg_balance": 0,
            "total_credits": 0, "total_debits": 0, "emi_obligations": 0,
            "foir": 0, "risk_score": 0, "credit_limit": 0,
            "months_analyzed": 0, "total_transactions": 0,
        },
        "income_breakdown": [],
        "spend_breakdown": [],
        "monthly_flow": [],
        "fraud_flags": ["No transactions found — could not analyze"],
        "decision": {"status": "DECLINE", "color": "danger", "reason": "Insufficient data"},
    }
