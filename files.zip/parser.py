"""
Bank Statement Parser
Handles PDF (pdfplumber), Excel (.xlsx/.xls), CSV formats
Supports 15+ Indian bank formats with intelligent detection
"""

import re
import io
from typing import Optional
from datetime import datetime, date
import pdfplumber
import pandas as pd
from bank_templates import (
    detect_bank, categorize_transaction, is_credit,
    clean_amount, PATTERNS
)


class ParsedStatement:
    def __init__(self):
        self.bank_name: str = "Unknown Bank"
        self.bank_key: str = "generic"
        self.account_holder: str = "Account Holder"
        self.account_number: str = "XXXX XXXX XXXX"
        self.ifsc: str = ""
        self.period_from: str = ""
        self.period_to: str = ""
        self.opening_balance: float = 0.0
        self.closing_balance: float = 0.0
        self.transactions: list = []
        self.raw_text: str = ""
        self.parse_confidence: float = 0.0  # 0-1
        self.errors: list = []

    def to_dict(self):
        return {
            "bank_name": self.bank_name,
            "bank_key": self.bank_key,
            "account_holder": self.account_holder,
            "account_number": self.account_number,
            "ifsc": self.ifsc,
            "period_from": self.period_from,
            "period_to": self.period_to,
            "opening_balance": self.opening_balance,
            "closing_balance": self.closing_balance,
            "transactions": self.transactions,
            "parse_confidence": round(self.parse_confidence, 2),
            "errors": self.errors,
        }


def _extract_meta(text: str, stmt: ParsedStatement):
    """Extract account holder name, number, IFSC from statement text."""
    patterns = {
        "account_holder": [
            r"(?:account\s*holder|customer\s*name|name)[:\s]+([A-Z][A-Za-z\s]{3,40})",
            r"(?:Mr\.|Mrs\.|Ms\.)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})",
            r"(?:account\s*name)[:\s]+([A-Z][A-Za-z\s]{3,40})",
        ],
        "account_number": [
            r"(?:account\s*(?:number|no|#))[:\s]*([X\d]{4,20}(?:\s*[X\d]{4,6})*)",
            r"(?:a/c\s*(?:no|number))[:\s]*([X\d\s]{8,25})",
            r"(?:account)[:\s]+(\d{9,18})",
        ],
        "ifsc": [
            r"(?:IFSC)[:\s]+([A-Z]{4}0[A-Z0-9]{6})",
            r"([A-Z]{4}0[A-Z0-9]{6})",
        ],
        "period": [
            r"(?:from|period)[:\s]+(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\s+(?:to)[:\s]+(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})",
            r"(\d{1,2}[-/]\d{1,2}[-/]\d{4})\s+to\s+(\d{1,2}[-/]\d{1,2}[-/]\d{4})",
            r"(\d{2}/\d{2}/\d{4})\s*[-–]\s*(\d{2}/\d{2}/\d{4})",
        ],
    }

    for field, pats in patterns.items():
        for pat in pats:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                if field == "account_holder" and len(m.group(1).strip()) > 3:
                    stmt.account_holder = m.group(1).strip()
                    break
                elif field == "account_number":
                    stmt.account_number = m.group(1).strip()
                    break
                elif field == "ifsc":
                    stmt.ifsc = m.group(1).strip()
                    break
                elif field == "period" and len(m.groups()) >= 2:
                    stmt.period_from = m.group(1).strip()
                    stmt.period_to = m.group(2).strip()
                    break


def _parse_transactions_from_text(text: str, bank_key: str) -> list:
    """Parse transactions from raw text using bank-specific patterns."""
    transactions = []
    lines = text.split("\n")

    patterns = PATTERNS.get(bank_key, []) + PATTERNS["generic"]

    for line in lines:
        line = line.strip()
        if len(line) < 15:
            continue

        for pattern in patterns:
            m = re.search(pattern, line, re.IGNORECASE)
            if m:
                groups = m.groups()
                if len(groups) < 3:
                    continue

                date_str = groups[0]
                description = groups[1].strip() if groups[1] else ""
                
                # Try to figure out debit/credit from groups
                amounts = [clean_amount(g) for g in groups[2:] if g and re.search(r"\d", str(g))]
                
                if not amounts or not description:
                    continue

                # Determine credit/debit
                cr_dr_match = re.search(r"\b(Cr|Dr)\b", line, re.IGNORECASE)
                cr_dr = cr_dr_match.group(1).upper() if cr_dr_match else ""
                
                is_cr = is_credit(description, cr_dr=cr_dr)
                
                # If 2+ amounts, first is usually debit, second credit (or vice versa)
                amount = 0.0
                if len(amounts) >= 2:
                    amount = amounts[1] if is_cr else amounts[0]
                    amount = amount if amount > 0 else max(amounts[:2])
                elif amounts:
                    amount = amounts[0]

                if amount <= 0:
                    continue

                # Balance is usually last amount
                balance = amounts[-1] if len(amounts) >= 2 else 0.0

                transactions.append({
                    "date": date_str,
                    "description": description[:80],
                    "type": "credit" if is_cr else "debit",
                    "amount": round(amount, 2),
                    "balance": round(balance, 2),
                    "category": categorize_transaction(description),
                    "ref": "",
                })
                break  # stop trying patterns if one matched

    return transactions


def _parse_excel_transactions(df: pd.DataFrame) -> list:
    """Parse transactions from a DataFrame (Excel/CSV)."""
    transactions = []
    df.columns = [str(c).lower().strip() for c in df.columns]

    # Common column name aliases
    col_aliases = {
        "date": ["date", "txn date", "transaction date", "value date", "posting date"],
        "description": ["description", "narration", "particulars", "details", "remarks", "transaction details"],
        "debit": ["debit", "dr", "withdrawal", "debit amount", "withdrawal amount"],
        "credit": ["credit", "cr", "deposit", "credit amount", "deposit amount"],
        "balance": ["balance", "closing balance", "running balance", "avl balance"],
    }

    def find_col(aliases):
        for alias in aliases:
            for col in df.columns:
                if alias in col:
                    return col
        return None

    date_col = find_col(col_aliases["date"])
    desc_col = find_col(col_aliases["description"])
    debit_col = find_col(col_aliases["debit"])
    credit_col = find_col(col_aliases["credit"])
    bal_col = find_col(col_aliases["balance"])

    if not date_col or not desc_col:
        return transactions

    for _, row in df.iterrows():
        try:
            date_val = str(row.get(date_col, "")).strip()
            desc = str(row.get(desc_col, "")).strip()
            
            if not date_val or not desc or date_val == "nan":
                continue

            debit = clean_amount(str(row.get(debit_col, 0))) if debit_col else 0
            credit = clean_amount(str(row.get(credit_col, 0))) if credit_col else 0
            balance = clean_amount(str(row.get(bal_col, 0))) if bal_col else 0

            if debit == 0 and credit == 0:
                continue

            if credit > 0:
                txn_type = "credit"
                amount = credit
            else:
                txn_type = "debit"
                amount = debit

            transactions.append({
                "date": date_val,
                "description": desc[:80],
                "type": txn_type,
                "amount": round(amount, 2),
                "balance": round(balance, 2),
                "category": categorize_transaction(desc),
                "ref": "",
            })
        except Exception:
            continue

    return transactions


def parse_pdf(file_bytes: bytes) -> ParsedStatement:
    """Parse a bank statement PDF."""
    stmt = ParsedStatement()
    full_text = ""

    try:
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ""
                full_text += text + "\n"

                # Also try table extraction
                tables = page.extract_tables()
                for table in tables:
                    for row in table:
                        if row:
                            row_text = " ".join([str(c) for c in row if c])
                            full_text += row_text + "\n"

        stmt.raw_text = full_text[:5000]  # Store first 5000 chars for AI

        # Detect bank
        stmt.bank_key = detect_bank(full_text)
        bank_display = {
            "hdfc": "HDFC Bank", "sbi": "State Bank of India",
            "icici": "ICICI Bank", "axis": "Axis Bank",
            "kotak": "Kotak Mahindra Bank", "yes": "Yes Bank",
            "pnb": "Punjab National Bank", "bob": "Bank of Baroda",
            "canara": "Canara Bank", "idfc": "IDFC First Bank",
            "indusind": "IndusInd Bank", "rbl": "RBL Bank",
            "federal": "Federal Bank", "generic": "Indian Bank",
        }
        stmt.bank_name = bank_display.get(stmt.bank_key, "Indian Bank")

        # Extract metadata
        _extract_meta(full_text, stmt)

        # Extract transactions
        stmt.transactions = _parse_transactions_from_text(full_text, stmt.bank_key)

        # Confidence based on how many transactions found
        if len(stmt.transactions) > 20:
            stmt.parse_confidence = 0.9
        elif len(stmt.transactions) > 10:
            stmt.parse_confidence = 0.75
        elif len(stmt.transactions) > 3:
            stmt.parse_confidence = 0.5
        else:
            stmt.parse_confidence = 0.2

    except Exception as e:
        stmt.errors.append(f"PDF parse error: {str(e)}")
        stmt.parse_confidence = 0.0

    return stmt


def parse_excel(file_bytes: bytes, filename: str = "") -> ParsedStatement:
    """Parse a bank statement Excel or CSV file."""
    stmt = ParsedStatement()

    try:
        if filename.endswith(".csv"):
            # Try multiple encodings
            for enc in ["utf-8", "latin-1", "cp1252"]:
                try:
                    df = pd.read_csv(io.BytesIO(file_bytes), encoding=enc, on_bad_lines="skip")
                    break
                except Exception:
                    continue
        else:
            df = pd.read_excel(io.BytesIO(file_bytes), engine="openpyxl")

        # Try to detect bank from column names or first rows
        header_text = " ".join([str(c) for c in df.columns]) + " " + " ".join([str(v) for v in df.iloc[0] if str(v) != "nan"][:5])
        stmt.bank_key = detect_bank(header_text)

        bank_display = {
            "hdfc": "HDFC Bank", "sbi": "State Bank of India",
            "icici": "ICICI Bank", "axis": "Axis Bank",
            "kotak": "Kotak Mahindra Bank", "generic": "Indian Bank",
        }
        stmt.bank_name = bank_display.get(stmt.bank_key, "Indian Bank")

        stmt.transactions = _parse_excel_transactions(df)
        stmt.parse_confidence = 0.85 if len(stmt.transactions) > 5 else 0.4
        stmt.raw_text = df.to_string(max_rows=50)

    except Exception as e:
        stmt.errors.append(f"Excel parse error: {str(e)}")

    return stmt


def parse_statement(file_bytes: bytes, filename: str) -> ParsedStatement:
    """Auto-detect file type and parse accordingly."""
    fname = filename.lower()
    if fname.endswith(".pdf"):
        return parse_pdf(file_bytes)
    elif fname.endswith((".xlsx", ".xls")):
        return parse_excel(file_bytes, filename)
    elif fname.endswith(".csv"):
        return parse_excel(file_bytes, filename)
    else:
        # Try PDF first, then Excel
        stmt = parse_pdf(file_bytes)
        if stmt.parse_confidence < 0.3:
            stmt = parse_excel(file_bytes, filename)
        return stmt
